public class Ninja{
    public static void main(String [] args){
        System.out.println("My name is John. I am a 999 years old. My hometown is Ventura, CA");
    }
}